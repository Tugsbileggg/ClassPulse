@echo off
rem ClassPulse AI-г энэ хавтас дотор суулгана: uv, Python 3.12, AI сангууд, YOLO26 загвар.
rem Системд юу ч суулгахгүй - хавтсыг устгахад бүгд устана.
chcp 65001 >nul
setlocal
cd /d "%~dp0.."

echo === ClassPulse AI суулгаж байна - интернэт хэрэгтэй, 10-20 минут ===
set "UV_PYTHON_INSTALL_DIR=%CD%\.python"
if not defined UV_CACHE_DIR set "UV_CACHE_DIR=%CD%\.cache\uv"
set "UV_PYTHON_PREFERENCE=only-managed"
set "UV_PYTHON_INSTALL_BIN=0"
set "UV_NO_MODIFY_PATH=1"
if not exist ".tools" mkdir ".tools"
if not exist ".cache" mkdir ".cache"

echo [1/5] Суулгагч - uv - татаж байна...
if exist ".tools\uv.exe" goto have_uv
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip' -OutFile '.cache\uv.zip'; Expand-Archive -Force '.cache\uv.zip' '.cache\uv'; Copy-Item (Get-ChildItem '.cache\uv' -Recurse -Filter 'uv.exe' | Select-Object -First 1).FullName '.tools\uv.exe'"
if errorlevel 1 exit /b 1
:have_uv

echo [2/5] Python 3.12 ...
".tools\uv.exe" python install 3.12
if errorlevel 1 exit /b 1
if exist ".venv\Scripts\python.exe" goto have_venv
".tools\uv.exe" venv --python 3.12 .venv
if errorlevel 1 exit /b 1
:have_venv

echo [3/5] AI сангууд - ойролцоогоор 1 GB ...
".tools\uv.exe" pip install --python ".venv\Scripts\python.exe" -r requirements.txt
if errorlevel 1 exit /b 1

echo [4/5] YOLO26 загвар ...
set PYTHONUTF8=1
".venv\Scripts\python.exe" -m camtrack.app --download-models
if errorlevel 1 exit /b 1

echo [5/5] Туршилтын мэдэгдэл илгээж байна...
".venv\Scripts\python.exe" -m camtrack.app --test-notification

rem The package cache - about 1 GB - is not needed once everything is installed.
if /i "%UV_CACHE_DIR%"=="%CD%\.cache\uv" rmdir /s /q "%UV_CACHE_DIR%"
type nul > ".venv\.ready"
echo === Суулгалт дууслаа ===
exit /b 0
