"""`camtrack detect`: run only the YOLO26 model on any video source.

No face recognition, ReID or tracking — just live YOLO26 boxes, for trying the detector on
video that did not come from the project's own door/ceiling phones: a downloaded clip, a feed
opened in some other app or browser, a USB webcam, or whatever is currently on the screen.

Sources:
  * --screen              grab the Mac's screen (or --region of it) with mss
  * --source PATH         video file
  * --source rtsp://...   camera URL (opened the same way as the door/ceiling streams)
  * --source 0            webcam index
"""

from __future__ import annotations

import logging
import time
from pathlib import Path

import cv2
import numpy as np

from camtrack.env import MODELS_DIR, disable_ultralytics_sync

log = logging.getLogger(__name__)

WINDOW = "camtrack detect"


class YoloDetector:
    """Generic YOLO26 detector (any/all COCO classes). Returns (N, 6): x1, y1, x2, y2, conf, cls."""

    def __init__(self, weights: str, imgsz: int = 640, conf: float = 0.35, device: str = "cpu",
                 classes: list[int] | None = None) -> None:
        from ultralytics import YOLO

        disable_ultralytics_sync()
        path = MODELS_DIR / weights
        if not path.exists():
            raise FileNotFoundError(f"{path} алга — `.venv/bin/python scripts/download_models.py` ажиллуулна уу")
        self.model = YOLO(str(path))
        self.names: dict[int, str] = self.model.names
        self.imgsz, self.conf, self.device, self.classes = imgsz, conf, device, classes
        self.name = f"{path.stem}@{imgsz}"
        self._warm = False

    def resolve_classes(self, spec: str | None) -> None:
        """Parse a `--classes` spec ("person,car" or "0,2") into COCO class ids."""
        if not spec:
            self.classes = None
            return
        name_to_id = {v.lower(): k for k, v in self.names.items()}
        ids = []
        for tok in (t.strip() for t in spec.split(",")):
            if not tok:
                continue
            if tok.isdigit():
                ids.append(int(tok))
            elif tok.lower() in name_to_id:
                ids.append(name_to_id[tok.lower()])
            else:
                raise ValueError(f"үл мэдэгдэх анги: {tok!r} (жиш: person,car эсвэл 0,2)")
        self.classes = ids or None

    def warmup(self) -> None:
        if not self._warm:
            self(np.zeros((720, 1280, 3), np.uint8))
            self._warm = True

    def __call__(self, image: np.ndarray) -> np.ndarray:
        r = self.model.predict(image, imgsz=self.imgsz, conf=self.conf, classes=self.classes,
                               device=self.device, verbose=False)[0]
        boxes = r.boxes
        if boxes is None or len(boxes) == 0:
            return np.zeros((0, 6), np.float32)
        return np.column_stack(
            [boxes.xyxy.cpu().numpy(), boxes.conf.cpu().numpy(), boxes.cls.cpu().numpy()]
        ).astype(np.float32)


def list_monitors() -> list[dict]:
    """Available screens, in the same order/indexing `--monitor` and mss use.

    Index 0 is every screen combined into one bounding box; 1, 2, ... are the individual
    physical displays (in the order macOS reports them).
    """
    import mss

    with mss.MSS() as sct:
        return list(sct.monitors)


class ScreenSource:
    """Captures one physical screen (or a region of it) as BGR frames via mss."""

    def __init__(self, monitor: int = 1, region: tuple[int, int, int, int] | None = None) -> None:
        import mss

        self._mss = mss.MSS()
        monitors = self._mss.monitors
        if not (0 <= monitor < len(monitors)):
            raise ValueError(f"--monitor {monitor} алга (0..{len(monitors) - 1} байх ёстой, "
                              f"`camtrack detect --list-screens` -ээр жагсаалт харна уу)")
        self.geometry = monitors[monitor]
        if region:
            x, y, w, h = region
            self._box = {"left": x, "top": y, "width": w, "height": h}
        else:
            self._box = self.geometry

    def read(self) -> np.ndarray:
        shot = self._mss.grab(self._box)
        return cv2.cvtColor(np.asarray(shot), cv2.COLOR_BGRA2BGR)

    def release(self) -> None:
        self._mss.close()


def auto_model(device: str) -> tuple[str, int]:
    """`model: auto`: m@1280 with a GPU (catches small/far people); s@960 on CPU so it stays usable."""
    return ("yolo26m.pt", 1280) if device in ("cuda", "mps") else ("yolo26s.pt", 960)


REGION_WINDOW = "ClassPulse AI - select area"


def select_region(monitor: int = 1) -> tuple[int, int, int, int] | None:
    """Let the user drag a rectangle over a screenshot; returns (x, y, w, h) in screen coordinates.

    Enter/Space confirms, Esc/c cancels (-> None). Coordinates are converted back from screenshot
    pixels to the screen's own units (points on a Retina Mac).
    """
    from camtrack.textdraw import draw_text

    src = ScreenSource(monitor)
    try:
        shot = src.read()
    finally:
        src.release()
    g = src.geometry
    px_per_unit = shot.shape[1] / g["width"]
    fit = min(1.0, 0.85 * g["width"] / shot.shape[1], 0.85 * g["height"] / shot.shape[0])
    view = cv2.resize(shot, (int(shot.shape[1] * fit), int(shot.shape[0] * fit)), interpolation=cv2.INTER_AREA)
    draw_text(view, "Камерын дүрс харагдаж буй хэсгийг хулганаар чирж сонгоод Enter дарна уу  (Esc: бүтэн дэлгэц)",
              (10, 10), size=22, color=(0, 255, 255))
    cv2.namedWindow(REGION_WINDOW, cv2.WINDOW_AUTOSIZE)
    try:
        x, y, w, h = cv2.selectROI(REGION_WINDOW, view, showCrosshair=False, fromCenter=False)
    finally:
        cv2.destroyWindow(REGION_WINDOW)
        for _ in range(5):
            cv2.waitKey(1)
    if w < 20 or h < 20:
        return None
    k = 1.0 / (fit * px_per_unit)
    return (g["left"] + round(x * k), g["top"] + round(y * k), round(w * k), round(h * k))


def print_screens() -> None:
    """`camtrack detect --list-screens`: show what --monitor N would pick, without starting anything."""
    mons = list_monitors()
    print("дэлгэцүүд (--monitor N-д ашиглах индекс):")
    for i, m in enumerate(mons):
        tag = " (бүх дэлгэц нэгтгэсэн)" if i == 0 else ""
        print(f"  {i}: {m['width']}x{m['height']}  at ({m['left']},{m['top']}){tag}")


def _open_video_source(source: str) -> cv2.VideoCapture:
    if source.isdigit():
        cap = cv2.VideoCapture(int(source))
    elif source.startswith(("rtsp://", "rtsps://", "http://", "https://")):
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
    else:
        cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"эх сурвалж нээгдсэнгүй: {source}")
    return cap


def _color_for(cls_id: int) -> tuple[int, int, int]:
    hue = (cls_id * 37) % 180
    b, g, r = cv2.cvtColor(np.uint8([[[hue, 200, 255]]]), cv2.COLOR_HSV2BGR)[0, 0]
    return int(b), int(g), int(r)


def _text(img: np.ndarray, text: str, org: tuple[int, int], scale: float = 0.6,
          color: tuple[int, int, int] = (255, 255, 255), thick: int = 1) -> None:
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), thick + 3, cv2.LINE_AA)
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def _draw_detections(img: np.ndarray, dets: np.ndarray, names: dict[int, str]) -> None:
    for x1, y1, x2, y2, c, cls in dets:
        cls = int(cls)
        color = _color_for(cls)
        p1, p2 = (int(x1), int(y1)), (int(x2), int(y2))
        cv2.rectangle(img, p1, p2, color, 2)
        label = f"{names.get(cls, cls)} {c:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(img, (p1[0], max(0, p1[1] - th - 6)), (p1[0] + tw + 4, p1[1]), color, -1)
        cv2.putText(img, label, (p1[0] + 2, max(12, p1[1] - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1,
                    cv2.LINE_AA)


def run(
    *,
    source: str | None,
    screen: bool,
    region: tuple[int, int, int, int] | None,
    weights: str,
    imgsz: int,
    conf: float,
    device_pref: str,
    classes: str | None,
    monitor: int = 1,
    window: bool = True,
    save: str | None = None,
    max_fps: float = 0.0,
    loop: bool = False,
    alert: bool = False,
    alert_hold_s: float = 10.0,
) -> int:
    from camtrack import device as devicemod

    dev = devicemod.torch_device(device_pref)
    if weights == "auto":
        weights, imgsz = auto_model(dev)
    det = YoloDetector(weights, imgsz=imgsz, conf=conf, device=dev)
    try:
        det.resolve_classes(classes)
    except ValueError as e:
        print(str(e))
        return 2
    log.info("%s, төхөөрөмж=%s, ангилал=%s", det.name, dev, classes or "бүгд")
    det.warmup()
    monitor_ = None
    if alert:
        from camtrack.alerts import BehaviorMonitor, draw_states

        monitor_ = BehaviorMonitor(det.names, hold_s=alert_hold_s)
        log.info("сэрэмжлүүлэг: асаалттай (утас оролдох / унтах, %.0f сек үргэлжилбэл мэдэгдэнэ)", alert_hold_s)
    states: list = []

    video: cv2.VideoCapture | None = None
    src: ScreenSource | None = None
    reader = None
    if screen:
        try:
            src = ScreenSource(monitor=monitor, region=region)
        except ValueError as e:
            print(str(e))
            return 2
        g = src.geometry
        box = region or (g["left"], g["top"], g["width"], g["height"])
        log.info("эх сурвалж: дэлгэц #%d (%dx%d at %d,%d)%s", monitor, g["width"], g["height"], g["left"], g["top"],
                  f" -> region {box}" if region else "")
    elif source.startswith(("rtsp://", "rtsps://", "http://", "https://")):
        # Live camera: a background thread drains the stream and keeps only the newest frame, so a
        # slow model never backs the stream up (the server dropped us after ~30-60 s otherwise), and
        # it reconnects by itself when the stream drops.
        from camtrack.streams import StreamReader

        reader = StreamReader("detect", source).start()
        log.info("эх сурвалж: %s (амьд урсгал, тасарвал автоматаар дахин холбогдоно)", reader.display_url)
    else:
        video = _open_video_source(source)
        log.info("эх сурвалж: %s", source)

    writer: cv2.VideoWriter | None = None
    if window:
        cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)

    frame_period = 1.0 / max_fps if max_fps > 0 else 0.0
    n = 0
    total_dets = 0
    last_idx = 0
    t0 = time.monotonic()
    last_print = t0
    try:
        while True:
            t_frame = t_img = time.monotonic()
            if src is not None:
                img = src.read()
                ok = True
            elif reader is not None:
                f = reader.wait(last_idx, timeout=1.0)
                if f is None:
                    if time.monotonic() - last_print >= 2.0:
                        last_print = time.monotonic()
                        log.info("урсгал ирэхгүй байна — дахин холбогдож байна (%s)", reader.stats.last_error or "...")
                    if window and (cv2.waitKey(1) & 0xFF) in (ord("q"), 27):
                        break
                    continue
                last_idx, t_img = f.idx, f.t
                img, ok = (f.image.copy() if window or save else f.image), True
            else:
                ok, img = video.read()
                if not ok and loop:
                    video.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, img = video.read()
            if not ok or img is None:
                log.info("эх сурвалж дууслаа (%d frame)", n)
                break

            dets = det(img)
            n += 1
            total_dets += len(dets)

            if monitor_ is not None:
                states = monitor_.update(img, dets, t_img)

            if window or save:
                _draw_detections(img, dets, det.names)
                if monitor_ is not None:
                    draw_states(img, states, alert_hold_s)
                fps = n / (time.monotonic() - t0) if time.monotonic() > t0 else 0.0
                _text(img, f"{det.name}  {len(dets)} object(s)  {fps:4.1f} fps avg  q: quit", (10, 28))

            if save:
                if writer is None:
                    h, w = img.shape[:2]
                    out_fps = 20.0
                    if video is not None:
                        vf = video.get(cv2.CAP_PROP_FPS)
                        out_fps = vf if vf and vf > 1 else out_fps
                    Path(save).parent.mkdir(parents=True, exist_ok=True)
                    writer = cv2.VideoWriter(save, cv2.VideoWriter_fourcc(*"mp4v"), out_fps, (w, h))
                writer.write(img)

            if window:
                cv2.imshow(WINDOW, img)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break

            now = time.monotonic()
            if now - last_print >= 2.0:
                last_print = now
                fps = n / (now - t0) if now > t0 else 0.0
                extra = ""
                if monitor_ is not None:
                    active = [f"#{st.track_id} " + "+".join(st.active) for st in states if st.active]
                    extra = f" | дагаж буй хүн {len(states)}, идэвхтэй: {', '.join(active) or '-'}"
                log.info("%d frame, %.1f fps дундаж, сүүлийн frame-д %d илрэлт%s", n, fps, len(dets), extra)

            if max_fps > 0:
                elapsed = time.monotonic() - t_frame
                time.sleep(max(0.0, frame_period - elapsed))
    except KeyboardInterrupt:
        pass
    finally:
        if src is not None:
            src.release()
        if video is not None:
            video.release()
        if reader is not None:
            reader.stop()
        if monitor_ is not None:
            from camtrack.alerts import purge_snapshots

            purge_snapshots()
        if writer is not None:
            writer.release()
        if window:
            cv2.destroyAllWindows()
            for _ in range(5):
                cv2.waitKey(1)

    span = time.monotonic() - t0
    print(f"\n=== detect дуусав: {n} frame, {span:.1f}s, дундаж {n / span if span > 0 else 0:.1f} fps, "
          f"нийт {total_dets} илрэлт ===")
    if save and writer is not None:
        print(f"хадгалсан: {save}")
    return 0
