"""ClassPulse AI: watch the part of the screen where the classroom camera software shows the class,
and notify the teacher when a student uses a phone or seems to sleep for a while.

    python -m camtrack.app                  first run asks for the area, later runs reuse it
    python -m camtrack.app --reselect       choose the area again
    python -m camtrack.app --preview        also show the detection window
    python -m camtrack.app --download-models / --test-notification   (used by the setup scripts)

Everything runs on this computer. Snapshots shown by the notifications are temporary (see alerts.py).
"""

from __future__ import annotations

import argparse
import logging
import signal
import sys

from camtrack import config as cfgmod
from camtrack import logutil
from camtrack.env import MODELS_DIR

log = logging.getLogger(__name__)

MODELS = ("yolo26s.pt", "yolo26m.pt")  # detect.auto_model picks one of these


def download_models() -> int:
    from ultralytics.utils.downloads import attempt_download_asset

    from camtrack.env import disable_ultralytics_sync

    disable_ultralytics_sync()
    for name in MODELS:
        path = attempt_download_asset(MODELS_DIR / name)
        print(f"  {name}: {MODELS_DIR / name}" if (MODELS_DIR / name).exists() else f"  {name}: {path}")
    missing = [n for n in MODELS if not (MODELS_DIR / n).exists()]
    if missing:
        print(f"Загвар татагдсангүй: {missing}. Интернэт холболтоо шалгаад дахин оролдоно уу.")
        return 1
    return 0


def test_notification() -> int:
    from camtrack.alerts import notify

    print("Туршилтын мэдэгдэл илгээж байна. Зөвшөөрөл асуувал «Allow / Зөвшөөрөх» дарна уу.")
    notify("ClassPulse AI", "Мэдэгдэл ажиллаж байна. Сурагч утас оролдох эсвэл унтахад ийм мэдэгдэл ирнэ.",
           timeout=90).join(95)
    return 0


def mac_screen_capture_allowed() -> bool:
    """macOS gives black/wallpaper-only screenshots until Terminal has Screen Recording permission."""
    import ctypes

    cg = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
    cg.CGPreflightScreenCaptureAccess.restype = ctypes.c_bool
    cg.CGRequestScreenCaptureAccess.restype = ctypes.c_bool
    if cg.CGPreflightScreenCaptureAccess():
        return True
    cg.CGRequestScreenCaptureAccess()  # system prompt; also adds Terminal to the settings list
    return False


def _stop_cleanly_on_close() -> None:
    """Closing the terminal window must still delete the temporary snapshots."""
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        from camtrack.alerts import purge_snapshots

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.DWORD)
        def handler(event: int) -> bool:
            if event in (2, 5, 6):  # CTRL_CLOSE_EVENT, CTRL_LOGOFF_EVENT, CTRL_SHUTDOWN_EVENT
                purge_snapshots()
            return False

        _stop_cleanly_on_close.handler = handler  # keep the callback alive
        ctypes.windll.kernel32.SetConsoleCtrlHandler(handler, True)
    else:
        for sig in (signal.SIGHUP, signal.SIGTERM):
            signal.signal(sig, lambda *_: sys.exit(0))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ClassPulse AI", description="Дэлгэц дээрх ангийн камерын дүрсээс утсаа "
                                 "оролдож эсвэл унтаж буй сурагчийг илрүүлж, багшид мэдэгдэнэ.")
    ap.add_argument("--reselect", action="store_true", help="хянах хэсгийг дахин сонгох")
    ap.add_argument("--preview", action="store_true", help="илрүүлэлтийг цонхонд харуулах")
    ap.add_argument("--download-models", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--test-notification", action="store_true", help=argparse.SUPPRESS)
    args = ap.parse_args(argv)
    logutil.setup(logging.INFO)

    if args.download_models:
        return download_models()
    if args.test_notification:
        return test_notification()

    from camtrack import detect

    if sys.platform == "darwin" and not mac_screen_capture_allowed():
        print("\nДЭЛГЭЦ ХАРАХ ЗӨВШӨӨРӨЛ ХЭРЭГТЭЙ")
        print("  1. System Settings → Privacy & Security → Screen & System Audio Recording нээнэ.")
        print("  2. Жагсаалтаас «Terminal»-ыг асаана.")
        print("  3. Terminal-ыг бүрэн хаагаад (Cmd+Q) «ClassPulse AI»-г дахин нээнэ.")
        return 1
    _stop_cleanly_on_close()
    cfg = cfgmod.load()
    monitor = int(cfg.get("detect.monitor", 1))
    region = cfg.get("calibration.detect_region")
    if args.reselect or not region:
        print("\nХЯНАХ ХЭСГЭЭ СОНГОНО УУ")
        print("  1. Камерын програмаа нээж, ангийн дүрсийг дэлгэцэн дээр гаргана уу.")
        print("  2. Удахгүй гарах дэлгэцийн зураг дээр камерын дүрс харагдаж буй хэсгийг хулганаар чирж сонгоно.")
        print("  3. Enter дарж баталгаажуулна (Esc — бүтэн дэлгэцийг хянана).")
        input("\nБэлэн болмогц Enter дарна уу...")
        region = detect.select_region(monitor)
        cfgmod.save_calibration({"detect_region": list(region) if region else None})
        print(f"Хянах хэсэг хадгалагдлаа: {region or 'бүтэн дэлгэц'}. Дахин сонгох бол --reselect.\n")

    print("ClassPulse AI ажиллаж байна. Мэдэгдэл дэлгэцийн буланд ирнэ. Зогсоох: энэ цонхонд Ctrl+C.\n")
    return detect.run(
        source=None,
        screen=True,
        region=tuple(int(v) for v in region) if region else None,
        weights=str(cfg.get("detect.model", "auto")),
        imgsz=int(cfg.get("detect.imgsz", 960)),
        conf=float(cfg.get("detect.conf", 0.25)),
        device_pref=str(cfg.get("models.device", "auto")),
        classes="person,cell phone",
        monitor=monitor,
        window=args.preview,
        alert=True,
        alert_hold_s=float(cfg.get("detect.alert_hold_s", 10.0)),
    )


if __name__ == "__main__":
    sys.exit(main())
