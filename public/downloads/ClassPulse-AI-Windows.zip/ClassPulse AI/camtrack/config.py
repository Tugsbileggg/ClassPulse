"""config.yaml (+ secrets from .env) loading and saving.

User settings live in config.yaml (commented). Values measured by the tools
(latencies, homography, zones, offsets) are written by the program into a
trailing `calibration:` block, so the hand-written part keeps its comments.
"""

from __future__ import annotations

import copy
import os
import re
from pathlib import Path
from typing import Any
from urllib.parse import quote

import yaml
from dotenv import load_dotenv

from camtrack.env import ROOT

CONFIG_PATH = ROOT / "config.yaml"
ENV_PATH = ROOT / ".env"
CALIB_MARKER = "# ==== calibration: written by `camtrack calibrate` / `camtrack test-streams --save` ===="

# Fallbacks for keys missing from config.yaml (config.yaml documents every key).
DEFAULTS: dict[str, Any] = {
    "cameras": {
        "door": {"url": ""},
        "ceiling": {"url": ""},
        "open_timeout_s": 6.0,
        "read_timeout_s": 5.0,
        "rtsp_transport": "tcp",
    },
    "models": {
        "device": "auto",
        "door_detector": "yolo26n.pt",
        "door_imgsz": 640,
        "ceiling_detector": "yolo26s.pt",
        "ceiling_imgsz": 1280,
        "person_conf": 0.35,
        "face_pack": "buffalo_l",
        "face_providers": "auto",
        "reid_weights": "osnet_x1_0_msmt17.pt",
    },
    "detect": {
        "screen": False,
        "monitor": 1,
        "model": "yolo26n.pt",
        "imgsz": 640,
        "conf": 0.35,
        "classes": "",
        "alert_hold_s": 10.0,
    },
    "calibration": {
        "latency_s": {"door": 0.0, "ceiling": 0.0},
    },
}

_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")
_CRED = re.compile(r"(://[^:/@\s]+):([^@\s]+)@")


def _deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def expand_vars(value: str) -> str:
    """Replace ${NAME} with the (URL-quoted) value from the environment / .env."""

    def sub(m: re.Match) -> str:
        name = m.group(1)
        if name not in os.environ:
            raise KeyError(f"${{{name}}} is used in config.yaml but not set in .env")
        return quote(os.environ[name], safe="")

    return _VAR.sub(sub, value)


def mask_url(url: str) -> str:
    """Hide the password part of a URL for printing/logging."""
    return _CRED.sub(r"\1:***@", url or "")


class Config(dict):
    """Nested dict with dotted-path access: cfg.get('models.door_imgsz')."""

    def get(self, key: str, default: Any = None) -> Any:  # type: ignore[override]
        node: Any = self
        for part in key.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = dict.get(node, part)
        return node

    def camera_url(self, name: str) -> str:
        url = self.get(f"cameras.{name}.url", "") or ""
        return expand_vars(str(url)).strip()

    def latency(self, name: str) -> float:
        return float(self.get(f"calibration.latency_s.{name}", 0.0) or 0.0)


def load(path: Path = CONFIG_PATH) -> Config:
    load_dotenv(ENV_PATH, override=False)
    data = {}
    if path.exists():
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return Config(_deep_merge(DEFAULTS, data))


def save_calibration(updates: dict, path: Path = CONFIG_PATH) -> dict:
    """Merge `updates` into the calibration block of config.yaml and rewrite only that block."""
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    current = (yaml.safe_load(text) or {}).get("calibration", {}) if text else {}
    merged = _deep_merge(DEFAULTS["calibration"], _deep_merge(current or {}, updates))

    idx = text.find(CALIB_MARKER)
    if idx < 0:  # no marker yet: drop a plain top-level `calibration:` block if present
        m = re.search(r"^calibration:.*\Z", text, flags=re.S | re.M)
        idx = m.start() if m else len(text)
    head = text[:idx].rstrip() + "\n\n" if text[:idx].strip() else ""
    block = yaml.safe_dump({"calibration": merged}, sort_keys=False, allow_unicode=True, default_flow_style=None)
    path.write_text(head + CALIB_MARKER + "\n" + block, encoding="utf-8")
    return merged


def set_camera_url(name: str, url: str, path: Path = CONFIG_PATH) -> None:
    """Replace `url:` of cameras.<name> in config.yaml, keeping comments intact."""
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    in_cameras = in_cam = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if re.match(r"^cameras:\s*(#.*)?$", line):
            in_cameras = True
            continue
        if in_cameras and re.match(r"^\S", line):
            break
        if in_cameras and re.match(rf"^  {name}:\s*(#.*)?$", line):
            in_cam = True
            continue
        if in_cam and re.match(r"^  \S", line):
            in_cam = False
        if in_cam and stripped.startswith("url:"):
            indent = line[: len(line) - len(line.lstrip())]
            comment = ""
            m = re.search(r"\s+#.*$", line.rstrip("\n"))
            if m and not re.search(r"""^url:\s*["'][^"']*#""", stripped):
                comment = m.group(0)
            lines[i] = f'{indent}url: "{url}"{comment}\n'
            path.write_text("".join(lines), encoding="utf-8")
            return
    raise KeyError(f"cameras.{name}.url not found in {path}")
