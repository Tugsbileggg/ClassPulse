"""camtrack: two-iPhone classroom person recognition and tracking (MVP)."""

from camtrack import env as _env  # noqa: F401  (sets local cache dirs before heavy imports)

__version__ = "0.1.0"
