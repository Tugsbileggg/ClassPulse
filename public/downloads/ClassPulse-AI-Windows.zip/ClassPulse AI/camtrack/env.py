"""Process environment for camtrack.

Must be imported before torch / ultralytics / insightface / boxmot so that:
  * every cache, config file and model download stays inside the project folder;
  * library telemetry / online checks / auto-installs are switched off
    (no image, video or face data ever leaves this computer).
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CACHE_DIR = ROOT / ".cache"
MODELS_DIR = ROOT / "models"
DATA_DIR = ROOT / "data"

_CACHE_DIRS = {
    "YOLO_CONFIG_DIR": CACHE_DIR / "ultralytics",
    "MPLCONFIGDIR": CACHE_DIR / "matplotlib",
    "TORCH_HOME": CACHE_DIR / "torch",
    "HF_HOME": CACHE_DIR / "huggingface",
}

for _key, _path in _CACHE_DIRS.items():
    os.environ.setdefault(_key, str(_path))
    Path(os.environ[_key]).mkdir(parents=True, exist_ok=True)

# Telemetry / network behaviour. Downloads are done explicitly by scripts/download_models.py.
os.environ.setdefault("YOLO_OFFLINE", "1")  # no online checks and no Ultralytics analytics events
os.environ.setdefault("YOLO_AUTOINSTALL", "False")  # never pip-install packages at runtime
os.environ.setdefault("YOLO_VERBOSE", "False")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("ORT_DISABLE_TELEMETRY", "1")
os.environ.setdefault("DO_NOT_TRACK", "1")
os.environ.setdefault("OPENCV_LOG_LEVEL", "ERROR")  # hide FFmpeg probing warnings
os.environ.setdefault("OPENCV_FFMPEG_LOGLEVEL", "8")  # FFmpeg: fatal only (MJPEG "overread" noise)
# Let unsupported MPS ops fall back to CPU instead of crashing.
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

MODELS_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)


def disable_ultralytics_sync() -> None:
    """Persist sync=False (and project-local dirs) in the Ultralytics settings file."""
    from ultralytics.utils import SETTINGS

    wanted = {
        "sync": False,
        "weights_dir": str(MODELS_DIR),
        "runs_dir": str(CACHE_DIR / "runs"),
        "datasets_dir": str(CACHE_DIR / "datasets"),
    }
    if any(SETTINGS.get(k) != v for k, v in wanted.items()):
        SETTINGS.update(wanted)
