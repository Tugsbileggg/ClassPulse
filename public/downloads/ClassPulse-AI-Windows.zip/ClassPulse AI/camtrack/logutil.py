"""Logging: human log (console + data/logs/camtrack-YYYYMMDD.log) and a JSONL decision log.

The decision log (data/logs/decisions-YYYYMMDD.jsonl) records every identity
decision (enrolment, match scores, handoff, re-ID, ...) for threshold tuning.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime
from pathlib import Path

from camtrack.env import DATA_DIR

LOG_DIR = DATA_DIR / "logs"


def setup(level: int = logging.INFO, to_file: bool = True) -> None:
    root = logging.getLogger()
    if getattr(root, "_camtrack_configured", False):
        return
    root.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(name)s: %(message)s", "%H:%M:%S")
    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(fmt)
    root.addHandler(console)
    if to_file:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(LOG_DIR / f"camtrack-{datetime.now():%Y%m%d}.log", encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter("%(asctime)s.%(msecs)03d %(levelname)-7s %(name)s: %(message)s",
                                          "%Y-%m-%d %H:%M:%S"))
        root.addHandler(fh)
    for noisy in ("ultralytics", "boxmot", "PIL", "matplotlib", "urllib3", "insightface"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    root._camtrack_configured = True  # type: ignore[attr-defined]


class DecisionLog:
    """Append-only JSON-lines log of identity decisions (thread-safe)."""

    def __init__(self, path: Path | None = None) -> None:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self.path = path or LOG_DIR / f"decisions-{datetime.now():%Y%m%d}.jsonl"
        self._lock = threading.Lock()

    def write(self, event: str, **fields) -> None:
        rec = {"ts": datetime.now().isoformat(timespec="milliseconds"), "mono": round(time.monotonic(), 3),
               "event": event, **fields}
        line = json.dumps(rec, ensure_ascii=False, default=_json_default)
        with self._lock, open(self.path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        logging.getLogger("camtrack.decision").debug(line)


def _json_default(o):
    try:
        import numpy as np

        if isinstance(o, np.generic):
            return o.item()
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    return str(o)
