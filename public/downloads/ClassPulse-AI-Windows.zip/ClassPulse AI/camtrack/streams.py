"""Low-latency camera stream readers.

One background thread per camera keeps only the newest decoded frame (older
frames are dropped), stamps it with time.monotonic() at arrival and reconnects
automatically (with back-off) when the stream stalls or the Wi-Fi drops.
"""

from __future__ import annotations

import logging
import os
import socket
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable
from urllib.parse import urlsplit

import cv2
import numpy as np

from camtrack.config import mask_url

log = logging.getLogger(__name__)

# FFmpeg demuxer options (read by OpenCV at every open).
#  rtsp_transport=tcp          : interleaved in the TCP session (IP Camera Lite rejects UDP: "461 Unsupported Transport")
#  allowed_media_types=video   : do NOT set up the audio track - with audio the iPhone RTSP stream stalls after
#                                a few seconds, and we never want classroom audio anyway
# (fflags=nobuffer/low_delay made the iPhone stream burstier, so they are not used; the reader thread drains
#  frames as fast as they arrive, which keeps latency low.)
_FFMPEG_OPTS = "rtsp_transport;{transport}|allowed_media_types;video"
_ENV_KEY = "OPENCV_FFMPEG_CAPTURE_OPTIONS"
_env_lock = threading.Lock()


def _set_capture_options(transport: str = "tcp") -> None:
    """Set the FFmpeg options env var once per process.

    Writing os.environ while another reader thread is inside FFmpeg (which calls getenv) is not
    thread-safe on macOS: with two cameras the readers stalled for seconds at a time. So the value
    is only written when it actually changes, under a lock, before any capture is opened.
    """
    value = _FFMPEG_OPTS.format(transport=transport)
    with _env_lock:
        if os.environ.get(_ENV_KEY) != value:
            os.environ[_ENV_KEY] = value


_set_capture_options("tcp")


@dataclass
class Frame:
    image: np.ndarray
    t: float  # time.monotonic() when the frame arrived on this computer
    idx: int  # 1-based frame counter of this reader
    source: str


@dataclass
class StreamStats:
    window_s: float = 3.0
    times: deque = field(default_factory=deque)
    width: int = 0
    height: int = 0
    frames: int = 0
    connects: int = 0
    failures: int = 0
    connected: bool = False
    last_error: str = ""
    last_frame_t: float = 0.0

    def on_frame(self, t: float, shape: tuple) -> None:
        self.frames += 1
        self.last_frame_t = t
        self.height, self.width = shape[:2]
        self.times.append(t)
        while self.times and self.times[0] < t - self.window_s:
            self.times.popleft()

    def fps(self, now: float | None = None) -> float:
        now = time.monotonic() if now is None else now
        if len(self.times) < 2 or now - self.times[-1] > 1.5:
            return 0.0
        return (len(self.times) - 1) / max(1e-6, self.times[-1] - self.times[0])


class StreamReader:
    """Reads one camera in a daemon thread; call latest() / wait() from any thread."""

    def __init__(
        self,
        name: str,
        url: str,
        *,
        open_timeout_s: float = 6.0,
        read_timeout_s: float = 5.0,
        rtsp_transport: str = "tcp",
        backoff: tuple[float, float] = (0.5, 5.0),
        on_frame: Callable[[Frame], None] | None = None,
    ) -> None:
        self.name = name
        self.url = url
        self.open_timeout_s = open_timeout_s
        self.read_timeout_s = read_timeout_s
        self.rtsp_transport = rtsp_transport
        self.backoff = backoff
        self.on_frame = on_frame
        self.stats = StreamStats()
        self._cond = threading.Condition()
        self._frame: Frame | None = None
        self._idx = 0
        self._stop = threading.Event()
        self._cap: cv2.VideoCapture | None = None
        self._thread = threading.Thread(target=self._run, name=f"reader-{name}", daemon=True)

    # ---------------------------------------------------------------- public
    def start(self) -> "StreamReader":
        self._thread.start()
        return self

    def stop(self, timeout: float = 3.0) -> None:
        self._stop.set()
        with self._cond:
            self._cond.notify_all()
        self._thread.join(timeout)

    def latest(self) -> Frame | None:
        with self._cond:
            return self._frame

    def wait(self, after_idx: int, timeout: float) -> Frame | None:
        """Block until a frame newer than after_idx arrives (or timeout); return the newest frame."""
        deadline = time.monotonic() + timeout
        with self._cond:
            while (self._frame is None or self._frame.idx <= after_idx) and not self._stop.is_set():
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._cond.wait(remaining)
            return self._frame if self._frame is not None and self._frame.idx > after_idx else None

    @property
    def display_url(self) -> str:
        return mask_url(self.url)

    # --------------------------------------------------------------- private
    def _open(self) -> cv2.VideoCapture | None:
        _set_capture_options(self.rtsp_transport)
        params = [
            cv2.CAP_PROP_OPEN_TIMEOUT_MSEC,
            int(self.open_timeout_s * 1000),
            cv2.CAP_PROP_READ_TIMEOUT_MSEC,
            int(self.read_timeout_s * 1000),
        ]
        cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG, params)
        if not cap.isOpened():
            cap.release()
            return None
        return cap

    def _run(self) -> None:
        delay = self.backoff[0]
        while not self._stop.is_set():
            cap = self._open()
            if cap is None:
                self.stats.failures += 1
                self.stats.last_error = "cannot open stream"
                log.warning("[%s] cannot open %s, retry in %.1fs", self.name, self.display_url, delay)
                self._stop.wait(delay)
                delay = min(delay * 2, self.backoff[1])
                continue
            self._cap = cap
            self.stats.connects += 1
            self.stats.connected = True
            self.stats.last_error = ""
            log.info("[%s] connected (%s)", self.name, self.display_url)
            got_frame = False
            while not self._stop.is_set():
                ok, img = cap.read()
                t = time.monotonic()
                if not ok or img is None:
                    self.stats.last_error = "stream ended / timed out"
                    break
                if not got_frame:
                    got_frame = True
                    delay = self.backoff[0]
                with self._cond:
                    self._idx += 1
                    frame = Frame(img, t, self._idx, self.name)
                    self._frame = frame
                    self._cond.notify_all()
                self.stats.on_frame(t, img.shape)
                if self.on_frame is not None:
                    try:
                        self.on_frame(frame)
                    except Exception:  # never let a consumer kill the reader
                        log.exception("[%s] on_frame callback failed", self.name)
            cap.release()
            self._cap = None
            self.stats.connected = False
            if not self._stop.is_set():
                self.stats.failures += 1
                log.warning("[%s] disconnected (%s), reconnecting in %.1fs", self.name, self.stats.last_error, delay)
                self._stop.wait(delay)
                delay = min(delay * 2, self.backoff[1])


# --------------------------------------------------------------------- probing
_PROBE_RTSP = [
    (8554, "/live"),
    (8554, "/"),
    (8554, "/live.sdp"),
    (8554, "/h264"),
    (8554, "/stream"),
    (554, "/live"),
    (554, "/"),
]
_PROBE_HTTP = [
    (8081, "/video"),
    (8081, "/live"),
    (8081, "/mjpeg"),
    (8081, "/video.mjpg"),
    (8081, "/videostream.cgi"),
    (8081, "/"),
    (8080, "/video"),
    (8080, "/videofeed"),
    (4747, "/video"),
]


def port_open(host: str, port: int, timeout: float = 0.8) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def discover_http_paths(host: str, port: int, user: str = "", password: str = "") -> list[str]:
    """Fetch the camera's web page and pull out stream-looking paths (img/video src, rtsp links)."""
    import base64
    import re
    import urllib.request

    req = urllib.request.Request(f"http://{host}:{port}/")
    if user:
        token = base64.b64encode(f"{user}:{password}".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            ctype = resp.headers.get("Content-Type", "")
            if "multipart" in ctype or "image" in ctype or "video" in ctype:
                return ["/"]  # the root itself is the stream
            html = resp.read(200_000).decode("utf-8", "ignore")
    except Exception as e:  # noqa: BLE001
        log.info("web page of %s:%s not readable: %s", host, port, e)
        return []
    paths: list[str] = []
    for m in re.finditer(r"""(?:src|href|data-src)\s*=\s*["']([^"'#]+)["']""", html, flags=re.I):
        p = m.group(1)
        if p.startswith(("http://", "https://")) and host not in p:
            continue
        p = re.sub(r"^https?://[^/]+", "", p)
        if any(k in p.lower() for k in ("video", "mjpg", "mjpeg", "stream", "live", "cam", ".jpg", "snapshot")):
            paths.append(p if p.startswith("/") else "/" + p)
    paths += re.findall(r"rtsp://[^\s\"'<>]+", html)
    return list(dict.fromkeys(paths))


def try_url(url: str, timeout_s: float = 5.0) -> tuple[bool, str]:
    """Open url and read one frame. Returns (ok, info)."""
    _set_capture_options("tcp")
    t0 = time.monotonic()
    cap = cv2.VideoCapture(
        url,
        cv2.CAP_FFMPEG,
        [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, int(timeout_s * 1000), cv2.CAP_PROP_READ_TIMEOUT_MSEC, int(timeout_s * 1000)],
    )
    try:
        if not cap.isOpened():
            return False, "cannot open"
        ok, img = cap.read()
        if not ok or img is None:
            return False, "opened but no frame"
        return True, f"{img.shape[1]}x{img.shape[0]} first frame after {time.monotonic() - t0:.1f}s"
    finally:
        cap.release()


def probe(host: str, user: str = "", password: str = "") -> list[tuple[str, str]]:
    """Try common iPhone IP-camera URLs on host; return [(url, info)] that deliver frames."""
    from urllib.parse import quote

    cred = f"{quote(user, safe='')}:{quote(password, safe='')}@" if user else ""
    found = []
    ports = {p for p, _ in _PROBE_RTSP + _PROBE_HTTP}
    open_ports = {p for p in sorted(ports) if port_open(host, p)}
    print(f"open ports on {host}: {sorted(open_ports) or 'none'}")
    http_table = list(_PROBE_HTTP)
    for port in sorted(p for p in open_ports if p not in (554, 8554)):
        extra = discover_http_paths(host, port, user, password)
        if extra:
            print(f"  paths found on the web page of :{port}: {extra}")
        for p in extra:
            if p.startswith("rtsp://"):
                continue
            if (port, p) not in http_table:
                http_table.insert(0, (port, p))
    tried = set()
    for scheme, table in (("rtsp", _PROBE_RTSP), ("http", http_table)):
        for port, path in table:
            if port not in open_ports or (scheme, port, path) in tried:
                continue
            tried.add((scheme, port, path))
            url = f"{scheme}://{cred}{host}:{port}{path}"
            ok, info = try_url(url)
            print(f"  {'OK ' if ok else '-- '} {mask_url(url):55s} {info}", flush=True)
            if ok:
                found.append((url, info))
    return found


def url_host(url: str) -> str:
    return urlsplit(url).hostname or ""
