"""Behaviour alerts for `camtrack detect --alert` / ClassPulse AI: "using a phone" / "maybe sleeping".

Heuristics on plain YOLO26 boxes (no pose/action model, per the project's "only YOLO26" rule):
  * phone: a `cell phone` box whose centre lies inside the (slightly enlarged) person box;
  * sleep: the person box is much wider than tall (lying down). Rough: misses someone sleeping
    upright with the head on the desk, and on fisheye / top-down cameras people near the edge
    look "wide" all the time.
People are followed with a small IoU tracker (students mostly sit still, a few fps is plenty).
A condition must hold for `hold_s` — short gaps up to GRACE_S are tolerated, because the small
phone is often missed for a frame or two — before ONE notification per episode is sent.

Snapshots (crop around the person) exist only so a click on the notification can show them: they
live in data/tmp-snapshots/ and are deleted when the program stops, and again at the next start in
case it was killed.
"""

from __future__ import annotations

import atexit
import logging
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

from camtrack.env import DATA_DIR, ROOT

log = logging.getLogger(__name__)

GRACE_S = 2.0
SLEEP_ASPECT_RATIO = 1.4
PHONE_MARGIN_PX = 20
SNAPSHOT_DIR = DATA_DIR / "tmp-snapshots"
APP_NAME = "ClassPulse AI"
WIN_PROTOCOL = "classpulse"

# kind -> (window label, BGR colour, notification title, notification body with {id} and {s})
KINDS = {
    "phone": ("phone using", (0, 0, 255), "Утас оролдож байна",
              "Хүн #{id} {s} секундээс удаан утсаа оролдож байна. Дарж зургийг харна уу."),
    "sleep": ("sleeping?", (0, 215, 255), "Унтаж байж магадгүй",
              "Хүн #{id} {s} секундээс удаан хэвтсэн байрлалтай байна. Дарж зургийг харна уу."),
}


@dataclass
class Episode:
    start: float
    last_true: float
    notified: bool = False


@dataclass
class PersonState:
    track_id: int
    box: np.ndarray
    active: dict[str, float] = field(default_factory=dict)  # kind -> seconds the condition has held


# ------------------------------------------------------------------ tracking
def _iou(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    x1 = np.maximum(a[:, None, 0], b[None, :, 0])
    y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2])
    y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (area_a[:, None] + area_b[None, :] - inter + 1e-9)


class IoUTracker:
    """Greedy IoU matching. No Kalman filter or ReID: seated students barely move between frames."""

    def __init__(self, iou_min: float = 0.3, max_age_s: float = 3.0) -> None:
        self.iou_min, self.max_age_s = iou_min, max_age_s
        self.tracks: dict[int, tuple[np.ndarray, float]] = {}  # id -> (box, last seen)
        self._next_id = 1

    def update(self, boxes: np.ndarray, t: float) -> list[tuple[int, np.ndarray]]:
        boxes = boxes[:, :4].astype(np.float32)
        ids = list(self.tracks)
        out: list[tuple[int, np.ndarray]] = []
        used_t: set[int] = set()
        used_d: set[int] = set()
        if ids and len(boxes):
            iou = _iou(np.stack([self.tracks[i][0] for i in ids]), boxes)
            for flat in np.argsort(-iou, axis=None):
                ti, di = divmod(int(flat), iou.shape[1])
                if iou[ti, di] < self.iou_min:
                    break
                if ti in used_t or di in used_d:
                    continue
                used_t.add(ti)
                used_d.add(di)
                out.append((ids[ti], boxes[di]))
        for di in range(len(boxes)):
            if di not in used_d:
                out.append((self._next_id, boxes[di]))
                self._next_id += 1
        for tid, box in out:
            self.tracks[tid] = (box, t)
        self.tracks = {k: v for k, v in self.tracks.items() if t - v[1] <= self.max_age_s}
        return out


# ------------------------------------------------------------------ conditions
def holds_phone(box: np.ndarray, phones: np.ndarray) -> bool:
    x1, y1, x2, y2 = box[:4]
    m = PHONE_MARGIN_PX
    for px1, py1, px2, py2, *_ in phones:
        cx, cy = (px1 + px2) / 2, (py1 + py2) / 2
        if x1 - m <= cx <= x2 + m and y1 - m <= cy <= y2 + m:
            return True
    return False


def looks_lying(box: np.ndarray) -> bool:
    x1, y1, x2, y2 = box[:4]
    return y2 > y1 and (x2 - x1) / (y2 - y1) > SLEEP_ASPECT_RATIO


# ------------------------------------------------------------------ snapshots
def purge_snapshots() -> None:
    shutil.rmtree(SNAPSHOT_DIR, ignore_errors=True)


def save_snapshot(img: np.ndarray, box: np.ndarray, phones: np.ndarray, kind: str, track_id: int) -> Path:
    """Crop around the person (with context): person in the kind's colour, phones in yellow."""
    h, w = img.shape[:2]
    x1, y1, x2, y2 = (int(v) for v in box[:4])
    vis = img.copy()
    for px1, py1, px2, py2, *_ in phones:
        cv2.rectangle(vis, (int(px1), int(py1)), (int(px2), int(py2)), (0, 220, 255), 2)
    cv2.rectangle(vis, (x1, y1), (x2, y2), KINDS[kind][1], 3)
    mx, my = max(80, (x2 - x1) // 2), max(80, (y2 - y1) // 2)
    crop = vis[max(0, y1 - my):min(h, y2 + my), max(0, x1 - mx):min(w, x2 + mx)]
    long_side = max(crop.shape[:2])
    if long_side < 480:
        s = 480 / long_side
        crop = cv2.resize(crop, (int(crop.shape[1] * s), int(crop.shape[0] * s)), interpolation=cv2.INTER_CUBIC)
    out = SNAPSHOT_DIR / f"{datetime.now():%H%M%S}_{kind}_person{track_id}.jpg"
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), crop, [cv2.IMWRITE_JPEG_QUALITY, 90])
    return out


# ------------------------------------------------------------------ notifications
def _applescript_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _mac_notifier() -> Path | None:
    """The clickable-notification helper built by scripts/build_notifier.sh (.tools/<Name>Notifier.app)."""
    for app in sorted((ROOT / ".tools").glob("*Notifier.app")):
        exe = app / "Contents" / "MacOS" / app.stem
        if exe.exists():
            return exe
    return None


def _notify_mac(title: str, body: str, open_path: Path | None, timeout: float) -> None:
    exe = _mac_notifier()
    if exe is not None:
        cmd = [str(exe), "--title", title, "--body", body] + (["--open", str(open_path)] if open_path else [])
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            if r.returncode == 0:
                return
            log.warning("мэдэгдлийн туслах програм: %s — энгийн мэдэгдэл рүү шилжлээ (System Settings → "
                        "Notifications-д %s-г зөвшөөрнө үү)", r.stderr.strip(), APP_NAME)
        except subprocess.TimeoutExpired:
            log.warning("мэдэгдлийн туслах програм хариу өгсөнгүй (зөвшөөрөл хүлээж байна уу?)")
    else:
        log.warning("мэдэгдлийн туслах програм алга (.tools/*Notifier.app) — дарахад зураг нээгдэхгүй")
    script = f'display notification "{_applescript_escape(body)}" with title "{_applescript_escape(title)}"'
    subprocess.run(["osascript", "-e", script], capture_output=True, timeout=10)


def register_windows_protocol() -> None:
    """Per-user `classpulse://` handler so a click on a toast opens the snapshot (camtrack/winopen.py)."""
    import winreg

    exe = Path(sys.executable)
    pythonw = exe.with_name("pythonw.exe")
    handler = Path(__file__).with_name("winopen.py")
    command = f'"{pythonw if pythonw.exists() else exe}" "{handler}" "%1"'
    base = rf"Software\Classes\{WIN_PROTOCOL}"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base) as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, f"URL:{APP_NAME}")
        winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\shell\open\command") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, command)


def _notify_windows(title: str, body: str, open_path: Path | None) -> None:
    from winotify import Notification, audio

    launch = f"{WIN_PROTOCOL}://open/{open_path.name}" if open_path else ""
    toast = Notification(app_id=APP_NAME, title=title, msg=body, launch=launch)
    toast.set_audio(audio.Default, loop=False)
    toast.show()


def notify(title: str, body: str, open_path: Path | None = None, timeout: float = 20.0) -> threading.Thread:
    """Post a desktop notification in a background thread; clicking it opens `open_path`."""

    def run() -> None:
        try:
            if sys.platform == "darwin":
                _notify_mac(title, body, open_path, timeout)
            elif sys.platform == "win32":
                _notify_windows(title, body, open_path)
            else:
                log.info("мэдэгдэл: %s — %s", title, body)
        except Exception:
            log.exception("мэдэгдэл илгээж чадсангүй")
            print(f"\a*** {title}: {body}", flush=True)

    th = threading.Thread(target=run, name="notify", daemon=True)
    th.start()
    return th


# ------------------------------------------------------------------ monitor
class BehaviorMonitor:
    def __init__(self, names: dict[int, str], hold_s: float = 10.0) -> None:
        name_to_id = {v.lower(): k for k, v in names.items()}
        self.person_id = name_to_id["person"]
        self.phone_id = name_to_id["cell phone"]
        self.hold_s = hold_s
        self.tracker = IoUTracker()
        self.episodes: dict[tuple[int, str], Episode] = {}
        purge_snapshots()  # leftovers of a run that was killed
        atexit.register(purge_snapshots)
        if sys.platform == "win32":
            try:
                register_windows_protocol()
            except OSError:
                log.exception("classpulse:// бүртгэж чадсангүй — мэдэгдэл дээр дарахад зураг нээгдэхгүй")

    def update(self, img: np.ndarray, dets: np.ndarray, t: float) -> list[PersonState]:
        cls = dets[:, 5].astype(int)
        persons, phones = dets[cls == self.person_id], dets[cls == self.phone_id]
        states = []
        for track_id, box in self.tracker.update(persons, t):
            st = PersonState(track_id, box)
            for kind, on in (("phone", holds_phone(box, phones)), ("sleep", looks_lying(box))):
                key = (track_id, kind)
                ep = self.episodes.get(key)
                if on:
                    if ep is None or t - ep.last_true > GRACE_S:
                        ep = self.episodes[key] = Episode(t, t)
                    ep.last_true = t
                    if not ep.notified and t - ep.start >= self.hold_s:
                        ep.notified = True
                        self._alert(kind, track_id, box, img, phones)
                if ep is not None and t - ep.last_true <= GRACE_S:
                    st.active[kind] = t - ep.start
            states.append(st)
        self.episodes = {k: e for k, e in self.episodes.items() if t - e.last_true <= GRACE_S}
        return states

    def _alert(self, kind: str, track_id: int, box: np.ndarray, img: np.ndarray, phones: np.ndarray) -> None:
        _, _, title, body = KINDS[kind]
        path = save_snapshot(img, box, phones, kind, track_id)
        body = body.format(id=track_id, s=int(self.hold_s))
        log.info("МЭДЭГДЭЛ: %s — %s", title, body)
        notify(title, body, path)


def draw_states(img: np.ndarray, states: list[PersonState], hold_s: float) -> None:
    for st in states:
        x1, y1, x2, y2 = (int(v) for v in st.box[:4])
        if not st.active:
            cv2.putText(img, f"#{st.track_id}", (x1 + 3, y2 - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2,
                        cv2.LINE_AA)
            continue
        color = KINDS["phone" if "phone" in st.active else "sleep"][1]
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 4)
        label = "  ".join(f"{KINDS[k][0]} {min(s, hold_s):.0f}/{hold_s:.0f}s" for k, s in st.active.items())
        label = f"#{st.track_id} {label}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        cv2.rectangle(img, (x1, y2), (x1 + tw + 8, y2 + th + 12), color, -1)
        cv2.putText(img, label, (x1 + 4, y2 + th + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2, cv2.LINE_AA)
