"""Windows handler for `classpulse://open/<file>` links (a clicked ClassPulse notification).

Registered per user by camtrack.alerts.register_windows_protocol(). Opens the snapshot with the
default image viewer — but only a plain .jpg name inside data/tmp-snapshots, so a classpulse:// link
from anywhere else (e.g. a web page) cannot open arbitrary files. Imports nothing from camtrack on
purpose: it runs as a plain script, from any working directory.
"""

import os
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit

SNAPSHOT_DIR = Path(__file__).resolve().parent.parent / "data" / "tmp-snapshots"


def main() -> None:
    if len(sys.argv) < 2:
        return
    name = unquote(urlsplit(sys.argv[1]).path).lstrip("/")
    if not name or Path(name).name != name or not name.lower().endswith(".jpg"):
        return
    path = SNAPSHOT_DIR / name
    if path.is_file():
        os.startfile(path)  # noqa: S606 (Windows only)


if __name__ == "__main__":
    main()
