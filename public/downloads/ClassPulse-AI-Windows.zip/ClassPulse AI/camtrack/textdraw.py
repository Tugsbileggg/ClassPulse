"""Cyrillic / Latin text on OpenCV (BGR) images via Pillow — cv2.putText only knows ASCII.

Rendered labels are cached as alpha masks, so drawing the same name every frame is cheap.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
    "/Library/Fonts/Arial Unicode.ttf",
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/System/Library/Fonts/SFNS.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",  # Linux
    "C:/Windows/Fonts/arial.ttf",  # Windows
]


@lru_cache(maxsize=1)
def font_path() -> str:
    for p in FONT_CANDIDATES:
        if Path(p).exists():
            return p
    raise FileNotFoundError("no TTF font with Cyrillic found; add one to textdraw.FONT_CANDIDATES")


@lru_cache(maxsize=16)
def _font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(font_path(), size)


@lru_cache(maxsize=4096)
def _mask(text: str, size: int) -> np.ndarray:
    """Anti-aliased text mask (uint8 HxW), tightly cropped with the font's line height."""
    font = _font(size)
    lines = text.split("\n")
    ascent, descent = font.getmetrics()
    line_h = ascent + descent
    width = max(1, max(int(np.ceil(font.getlength(line))) for line in lines))
    img = Image.new("L", (width, line_h * len(lines)), 0)
    draw = ImageDraw.Draw(img)
    for i, line in enumerate(lines):
        draw.text((0, i * line_h), line, font=font, fill=255)
    return np.asarray(img, dtype=np.uint8)


def text_size(text: str, size: int = 20, pad: int = 4) -> tuple[int, int]:
    h, w = _mask(text, size).shape
    return w + 2 * pad, h + 2 * pad


def draw_text(
    img: np.ndarray,
    text: str,
    org: tuple[int, int],
    size: int = 20,
    color: tuple[int, int, int] = (255, 255, 255),
    bg: tuple[int, int, int] | None = (0, 0, 0),
    bg_alpha: float = 0.65,
    pad: int = 4,
    anchor: str = "lt",
) -> tuple[int, int, int, int]:
    """Draw text (BGR colors) at org. anchor: 'lt' left-top, 'lb' left-bottom, 'ct' centre-top.

    Returns the drawn box (x1, y1, x2, y2), clipped to the image.
    """
    if not text:
        return (org[0], org[1], org[0], org[1])
    mask = _mask(text, size)
    mh, mw = mask.shape
    bw, bh = mw + 2 * pad, mh + 2 * pad
    x, y = int(org[0]), int(org[1])
    if anchor[0] == "c":
        x -= bw // 2
    if anchor[1] == "b":
        y -= bh
    H, W = img.shape[:2]
    x1, y1, x2, y2 = max(0, x), max(0, y), min(W, x + bw), min(H, y + bh)
    if x1 >= x2 or y1 >= y2:
        return (x1, y1, x1, y1)
    roi = img[y1:y2, x1:x2].astype(np.float32)
    if bg is not None and bg_alpha > 0:
        roi = roi * (1 - bg_alpha) + np.array(bg, np.float32) * bg_alpha
    # text mask placed inside the padded box
    full = np.zeros((bh, bw), np.float32)
    full[pad : pad + mh, pad : pad + mw] = mask / 255.0
    a = full[y1 - y : y2 - y, x1 - x : x2 - x][..., None]
    roi = roi * (1 - a) + np.array(color, np.float32) * a
    img[y1:y2, x1:x2] = roi.astype(np.uint8)
    return (x1, y1, x2, y2)
