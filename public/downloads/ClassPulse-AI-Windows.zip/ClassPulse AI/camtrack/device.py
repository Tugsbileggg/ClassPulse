"""Compute device selection: CUDA -> MPS -> CPU for torch, and matching ONNX Runtime providers."""

from __future__ import annotations

from functools import lru_cache

from camtrack.env import CACHE_DIR


@lru_cache(maxsize=None)
def torch_device(preference: str = "auto") -> str:
    """Return 'cuda', 'mps' or 'cpu'. An explicit preference is honoured if available."""
    import torch

    pref = (preference or "auto").lower()
    if pref in ("cuda", "cuda:0") and torch.cuda.is_available():
        return "cuda"
    if pref == "mps" and torch.backends.mps.is_available():
        return "mps"
    if pref == "cpu":
        return "cpu"
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def onnx_providers(preference: str = "auto") -> list:
    """ONNX Runtime providers in priority order (CUDA -> CoreML -> CPU).

    preference: 'auto' | 'cuda' | 'coreml' | 'cpu'
    """
    import onnxruntime as ort

    available = set(ort.get_available_providers())
    pref = (preference or "auto").lower()
    coreml = (
        "CoreMLExecutionProvider",
        {"ModelCacheDirectory": str(CACHE_DIR / "coreml"), "MLComputeUnits": "ALL"},
    )
    if pref == "cpu":
        return ["CPUExecutionProvider"]
    if pref in ("auto", "cuda") and "CUDAExecutionProvider" in available:
        return ["CUDAExecutionProvider", "CPUExecutionProvider"]
    if pref in ("auto", "coreml") and "CoreMLExecutionProvider" in available:
        return [coreml, "CPUExecutionProvider"]
    return ["CPUExecutionProvider"]


def describe() -> str:
    """One-line human readable summary of the compute setup."""
    import platform

    import onnxruntime as ort
    import torch

    dev = torch_device()
    extra = ""
    if dev == "cuda":
        extra = f" ({torch.cuda.get_device_name(0)})"
    return (
        f"{platform.system()} {platform.machine()}, torch {torch.__version__} -> {dev}{extra}; "
        f"onnxruntime {ort.__version__} providers={ort.get_available_providers()}"
    )
