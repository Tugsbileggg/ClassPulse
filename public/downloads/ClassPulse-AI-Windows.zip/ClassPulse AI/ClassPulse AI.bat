@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
title ClassPulse AI

if exist ".venv\.ready" goto run
call "scripts\setup.bat"
if errorlevel 1 goto setup_failed

:run
".venv\Scripts\python.exe" -m camtrack.app %*
echo.
echo ClassPulse AI зогслоо.
pause
exit /b 0

:setup_failed
echo.
echo Суулгалт амжилтгүй боллоо. Дээрх алдааг харна уу.
pause
exit /b 1
