@echo off
call "%~dp0ClassPulse AI.bat" --reselect
