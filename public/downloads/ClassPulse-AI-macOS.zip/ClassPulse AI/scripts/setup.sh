#!/usr/bin/env bash
# ClassPulse AI-г энэ хавтас дотор суулгана: uv, Python 3.12, AI сангууд, YOLO26 загвар.
# Системд юу ч суулгахгүй — хавтсыг устгахад бүгд устана.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "=== ClassPulse AI суулгаж байна (интернэт хэрэгтэй, 10-20 минут) ==="
if [ "$(uname -m)" != "arm64" ]; then
  echo "Уучлаарай: Apple Silicon (M1/M2/M3/M4) процессортой Mac шаардлагатай."; exit 1
fi
if [ "$(sw_vers -productVersion | cut -d. -f1)" -lt 14 ]; then
  echo "Уучлаарай: macOS 14 (Sonoma) эсвэл түүнээс шинэ хувилбар шаардлагатай."; exit 1
fi
# Files unzipped from a download are quarantined; the bundled notification helper would be blocked.
xattr -dr com.apple.quarantine . 2>/dev/null || true

export UV_PYTHON_INSTALL_DIR="$PWD/.python" UV_CACHE_DIR="${UV_CACHE_DIR:-$PWD/.cache/uv}" \
       UV_PYTHON_PREFERENCE=only-managed UV_PYTHON_INSTALL_BIN=0 UV_NO_MODIFY_PATH=1
mkdir -p .tools .cache

echo "[1/5] Суулгагч (uv) татаж байна..."
if [ ! -x .tools/uv ]; then
  curl -fsSL -o .cache/uv.tar.gz https://github.com/astral-sh/uv/releases/latest/download/uv-aarch64-apple-darwin.tar.gz
  tar -xzf .cache/uv.tar.gz -C .tools --strip-components=1
fi
echo "[2/5] Python 3.12 ..."
.tools/uv python install 3.12
[ -x .venv/bin/python ] || .tools/uv venv --python 3.12 .venv
echo "[3/5] AI сангууд (~1 GB) ..."
.tools/uv pip install --python .venv/bin/python -r requirements.txt
echo "[4/5] YOLO26 загвар ..."
.venv/bin/python -m camtrack.app --download-models
echo "[5/5] Мэдэгдэл шалгаж байна..."
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
  -f .tools/ClassPulseNotifier.app >/dev/null 2>&1 || true
.venv/bin/python -m camtrack.app --test-notification || true
# The package cache (~1 GB) is not needed once everything is installed.
if [ "$UV_CACHE_DIR" = "$PWD/.cache/uv" ]; then rm -rf "$UV_CACHE_DIR"; fi
touch .venv/.ready
echo "=== Суулгалт дууслаа ==="
