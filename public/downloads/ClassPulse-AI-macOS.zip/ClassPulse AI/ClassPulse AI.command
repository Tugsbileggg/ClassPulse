#!/bin/bash
# ClassPulse AI — давхар товшиж эхлүүлнэ. Анх удаа энэ хавтас дотор автоматаар суулгана.
cd "$(dirname "${BASH_SOURCE[0]:-$0}")" || exit 1
pause() { echo; read -n 1 -s -r -p "$1"; echo; }

if [ ! -f .venv/.ready ]; then
  if ! bash scripts/setup.sh; then
    pause "Суулгалт амжилтгүй боллоо. Дээрх алдааг харна уу. Хаахын тулд дурын товч дарна уу..."
    exit 1
  fi
fi
# The folder may have been moved: let macOS find the notification helper again (needed for clicks).
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
  -f .tools/ClassPulseNotifier.app >/dev/null 2>&1 || true

.venv/bin/python -m camtrack.app "$@"
pause "ClassPulse AI зогслоо. Хаахын тулд дурын товч дарна уу..."
