#!/bin/bash
# Камерын дүрс харагдах хэсгийг дахин сонгоод ClassPulse AI-г эхлүүлнэ.
exec bash "$(dirname "${BASH_SOURCE[0]:-$0}")/ClassPulse AI.command" --reselect
